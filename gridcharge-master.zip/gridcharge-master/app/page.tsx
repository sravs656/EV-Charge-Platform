"use client";

import {
  Activity,
  BatteryCharging,
  Car,
  ChevronRight,
  CircleDollarSign,
  Gauge,
  LayoutDashboard,
  LogOut,
  MapPin,
  Menu,
  Settings,
  X,
  Zap,
} from "lucide-react";

import {
  useEffect,
  useState,
  type ReactNode,
} from "react";

import { createClient } from "@/lib/supabase/client";
import { ChargingCalculator } from "@/components/charging-calculator";

type Station = {
  ID: number;
  AddressInfo?: {
    Title?: string;
    Town?: string;
    StateOrProvince?: string;
    Latitude?: number;
    Longitude?: number;
  };
  Connections?: {
    PowerKW?: number;
    Quantity?: number;
    ConnectionType?: {
      Title?: string;
      FormalName?: string;
    };
  }[];
};

type Vehicle = {
  id: string;
  name: string;
  demand: number;
  priority: number;
  battery: number;
};

type Allocation = Vehicle & {
  allocated: number;
  status: "Charging" | "Throttled" | "Waiting";
};

const vehicles: Vehicle[] = [
  {
    id: "EV-001",
    name: "Delivery Van",
    demand: 70,
    priority: 10,
    battery: 35,
  },
  {
    id: "EV-002",
    name: "Fleet Car",
    demand: 50,
    priority: 7,
    battery: 22,
  },
  {
    id: "EV-003",
    name: "Taxi",
    demand: 60,
    priority: 5,
    battery: 28,
  },
  {
    id: "EV-004",
    name: "Service Van",
    demand: 40,
    priority: 8,
    battery: 18,
  },
  {
    id: "EV-005",
    name: "Electric Bike",
    demand: 1,
    priority: 6,
    battery: 4,
  },
];

function optimizePower(siteLimit: number): Allocation[] {
  let remaining = siteLimit;

  // Higher priority vehicles receive available power first.
  const orderedVehicles = [...vehicles].sort(
    (a, b) => b.priority - a.priority
  );

  const allocatedVehicles = orderedVehicles.map(
    (vehicle) => {
      const allocated = Math.min(
        vehicle.demand,
        Math.max(remaining, 0)
      );

      remaining -= allocated;

      let status: Allocation["status"];

      if (allocated === vehicle.demand) {
        status = "Charging";
      } else if (allocated > 0) {
        status = "Throttled";
      } else {
        status = "Waiting";
      }

      return {
        ...vehicle,
        allocated,
        status,
      };
    }
  );

  // Keep the normal vehicle order on the dashboard.
  return vehicles.map(
    (vehicle) =>
      allocatedVehicles.find(
        (item) => item.id === vehicle.id
      )!
  );
}

export default function Home() {
  const [stations, setStations] =
    useState<Station[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [siteLimit, setSiteLimit] =
    useState(150);

  const [tariff, setTariff] =
    useState(8);

  const [activeSection, setActiveSection] =
    useState("Home");

  const [mobileMenu, setMobileMenu] =
    useState(false);

  const [stationSearch, setStationSearch] =
    useState("");

  const [appliedSearch, setAppliedSearch] =
    useState("");

  const allocations =
    optimizePower(siteLimit);

  const totalDemand = vehicles.reduce(
    (sum, vehicle) =>
      sum + vehicle.demand,
    0
  );

  const totalAllocated =
    allocations.reduce(
      (sum, vehicle) =>
        sum + vehicle.allocated,
      0
    );

  const chargingHours = 1;

  const energyUsed =
    totalAllocated * chargingHours;

  const estimatedCost =
    energyUsed * tariff;

  const overloaded =
    totalDemand > siteLimit;

  const utilization = Math.min(
    Math.round(
      (totalAllocated /
        Math.max(siteLimit, 1)) *
        100
    ),
    100
  );

  useEffect(() => {
    const loadStations = async () => {
      setLoading(true);

      try {
        const query =
          appliedSearch.trim()
            ? `?city=${encodeURIComponent(
                appliedSearch.trim()
              )}`
            : "";

        const response =
          await fetch(
            `/api/stations${query}`
          );

        if (!response.ok) {
          throw new Error(
            "Failed to load stations"
          );
        }

        const data: unknown =
          await response.json();

        if (Array.isArray(data)) {
          setStations(
            data as Station[]
          );
        } else {
          setStations([]);
        }
      } catch (error) {
        console.error(
          "Station fetch failed:",
          error
        );

        setStations([]);
      } finally {
        setLoading(false);
      }
    };

    loadStations();
  }, [appliedSearch]);

  const handleLogout = async () => {
    const supabase =
      createClient();

    await supabase.auth.signOut();

    window.location.href =
      "/auth/login";
  };

  const navigation = [
    {
      name: "Home",
      icon: LayoutDashboard,
    },
    {
      name: "Charging",
      icon: BatteryCharging,
    },
    {
      name: "Vehicles",
      icon: Car,
    },
    {
      name: "Stations",
      icon: MapPin,
    },
    {
      name: "Costs",
      icon: CircleDollarSign,
    },
    {
      name: "Settings",
      icon: Settings,
    },
  ];

  const selectSection = (
    section: string
  ) => {
    setActiveSection(section);
    setMobileMenu(false);
  };

  const searchStations = () => {
    setAppliedSearch(
      stationSearch.trim()
    );
  };

  const showAllIndia = () => {
    setStationSearch("");
    setAppliedSearch("");
  };

  return (
    <main className="min-h-screen bg-[#050816] text-white">
      <div className="flex min-h-screen">

        {/* SIDEBAR */}

        <aside
          className={`fixed inset-y-0 left-0 z-50 w-72 border-r border-white/10 bg-[#080c1c] transition-transform duration-300 lg:static lg:translate-x-0 ${
            mobileMenu
              ? "translate-x-0"
              : "-translate-x-full"
          }`}
        >
          <div className="flex h-full flex-col p-5">

            <div className="flex items-center justify-between px-2 py-3">
              <div className="flex items-center gap-3">

                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-500/15 text-orange-400">
                  <Zap
                    size={24}
                    fill="currentColor"
                  />
                </div>

                <div>
                  <p className="text-lg font-bold">
                    GridCharge
                  </p>

                  <p className="text-xs text-slate-500">
                    EV Energy Platform
                  </p>
                </div>

              </div>

              <button
                type="button"
                onClick={() =>
                  setMobileMenu(false)
                }
                className="rounded-lg p-2 text-slate-400 hover:bg-white/5 lg:hidden"
              >
                <X size={20} />
              </button>

            </div>

            <div className="mt-10">

              <p className="px-3 text-xs font-semibold uppercase tracking-widest text-slate-600">
                Workspace
              </p>

              <nav className="mt-3 space-y-1">

                {navigation.map(
                  (item) => {
                    const Icon =
                      item.icon;

                    const active =
                      activeSection ===
                      item.name;

                    return (
                      <button
                        type="button"
                        key={item.name}
                        onClick={() =>
                          selectSection(
                            item.name
                          )
                        }
                        className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm font-medium transition ${
                          active
                            ? "bg-orange-500/10 text-orange-400 ring-1 ring-orange-500/10"
                            : "text-slate-400 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        <Icon size={19} />

                        <span>
                          {item.name}
                        </span>

                        {active && (
                          <ChevronRight
                            size={16}
                            className="ml-auto opacity-70"
                          />
                        )}
                      </button>
                    );
                  }
                )}

              </nav>
            </div>

            <div className="mt-8 rounded-2xl border border-emerald-500/10 bg-emerald-500/5 p-4">

              <div className="flex items-center gap-2">

                <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]" />

                <span className="text-sm font-medium text-emerald-400">
                  System Online
                </span>

              </div>

              <p className="mt-2 text-xs leading-5 text-slate-500">
                Grid optimization engine
                is actively managing fleet
                power.
              </p>

            </div>

            <div className="mt-auto">

              <div className="mb-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">

                <div className="flex items-center gap-3">

                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-orange-400 to-orange-600 font-bold text-slate-950">
                    A
                  </div>

                  <div className="min-w-0">

                    <p className="truncate text-sm font-semibold">
                      Fleet Admin
                    </p>

                    <p className="truncate text-xs text-slate-500">
                      GridCharge User
                    </p>

                  </div>

                </div>

              </div>

              <button
                type="button"
                onClick={handleLogout}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-slate-400 transition hover:bg-red-500/10 hover:text-red-400"
              >
                <LogOut size={19} />
                Logout
              </button>

            </div>

          </div>
        </aside>

        {mobileMenu && (
          <button
            type="button"
            aria-label="Close menu"
            onClick={() =>
              setMobileMenu(false)
            }
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          />
        )}

        {/* MAIN */}

        <section className="min-w-0 flex-1">

          <header className="sticky top-0 z-30 border-b border-white/10 bg-[#050816]/90 px-5 py-4 backdrop-blur-xl md:px-8">

            <div className="flex items-center justify-between">

              <button
                type="button"
                onClick={() =>
                  setMobileMenu(true)
                }
                className="rounded-xl border border-white/10 bg-white/[0.03] p-2 text-slate-300 lg:hidden"
              >
                <Menu size={20} />
              </button>

              <div className="hidden lg:block">

                <p className="text-xs uppercase tracking-widest text-slate-600">
                  Fleet Operations
                </p>

              </div>

              <div className="ml-auto flex items-center gap-3">

                <div className="hidden rounded-full border border-emerald-500/20 bg-emerald-500/5 px-3 py-1.5 text-xs text-emerald-400 sm:block">
                  ● Live system
                </div>

                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-orange-500/15 text-sm font-bold text-orange-400">
                  A
                </div>

              </div>

            </div>

          </header>

          <div className="mx-auto max-w-[1600px] p-5 md:p-8">

            {/* HOME */}

            {activeSection ===
              "Home" && (
              <>

                <div className="mb-8">

                  <p className="text-sm font-medium text-orange-400">
                    GRIDCHARGE CONTROL CENTER
                  </p>

                  <h1 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">
                    Good to see you 👋
                  </h1>

                  <p className="mt-2 text-sm text-slate-500 md:text-base">
                    Monitor your fleet,
                    manage grid capacity,
                    and optimize charging
                    costs.
                  </p>

                </div>

                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

                  <MetricCard
                    label="Site Capacity"
                    value={`${siteLimit} kW`}
                    description="Configured grid limit"
                    icon={
                      <Gauge size={19} />
                    }
                    iconClass="text-orange-400"
                  />

                  <MetricCard
                    label="Fleet Demand"
                    value={`${totalDemand} kW`}
                    description={
                      overloaded
                        ? `${totalDemand - siteLimit} kW above limit`
                        : "Within grid limit"
                    }
                    icon={
                      <Activity size={19} />
                    }
                    iconClass={
                      overloaded
                        ? "text-red-400"
                        : "text-emerald-400"
                    }
                  />

                  <MetricCard
                    label="Power Allocated"
                    value={`${totalAllocated} kW`}
                    description="Optimized allocation"
                    icon={
                      <BatteryCharging
                        size={19}
                      />
                    }
                    iconClass="text-emerald-400"
                  />

                  <MetricCard
                    label="Estimated Cost"
                    value={`₹${estimatedCost.toFixed(
                      0
                    )}`}
                    description="Current charging session"
                    icon={
                      <CircleDollarSign
                        size={19}
                      />
                    }
                    iconClass="text-purple-400"
                  />

                </div>

                <div className="mt-6 grid gap-6 xl:grid-cols-3">

                  <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6 xl:col-span-2">

                    <div className="flex flex-col justify-between gap-4 sm:flex-row">

                      <div>

                        <p className="text-xs font-semibold uppercase tracking-widest text-slate-600">
                          Grid utilization
                        </p>

                        <h2 className="mt-2 text-xl font-semibold">
                          {utilization}% of
                          available capacity
                        </h2>

                        <p className="mt-1 text-sm text-slate-500">
                          {totalAllocated} kW
                          allocated from{" "}
                          {siteLimit} kW
                          available.
                        </p>

                      </div>

                      <div
                        className={`rounded-xl px-4 py-2 text-sm font-medium ${
                          overloaded
                            ? "bg-red-500/10 text-red-400"
                            : "bg-emerald-500/10 text-emerald-400"
                        }`}
                      >
                        {overloaded
                          ? "⚠ Capacity Alert"
                          : "✓ Grid Stable"}
                      </div>

                    </div>

                    <div className="mt-7 h-4 overflow-hidden rounded-full bg-slate-800">

                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          overloaded
                            ? "bg-red-500"
                            : "bg-gradient-to-r from-orange-500 to-emerald-400"
                        }`}
                        style={{
                          width: `${utilization}%`,
                        }}
                      />

                    </div>

                    <div className="mt-3 flex justify-between text-xs text-slate-600">
                      <span>0 kW</span>

                      <span>
                        {siteLimit} kW limit
                      </span>
                    </div>

                  </div>

                  <div className="rounded-2xl border border-orange-500/10 bg-orange-500/[0.035] p-6">

                    <div className="flex items-center gap-3">

                      <div className="rounded-xl bg-orange-500/10 p-2 text-orange-400">
                        <Zap size={19} />
                      </div>

                      <div>

                        <p className="text-sm font-semibold">
                          Power Control
                        </p>

                        <p className="text-xs text-slate-500">
                          Adjust grid limit
                        </p>

                      </div>

                    </div>

                    <div className="mt-6 flex items-end justify-between">

                      <span className="text-xs text-slate-500">
                        Site limit
                      </span>

                      <span className="text-2xl font-bold text-orange-400">
                        {siteLimit} kW
                      </span>

                    </div>

                    <input
                      type="range"
                      min="50"
                      max="250"
                      step="10"
                      value={siteLimit}
                      onChange={(e) =>
                        setSiteLimit(
                          Number(
                            e.target.value
                          )
                        )
                      }
                      className="mt-5 w-full accent-orange-500"
                    />

                    <div className="mt-2 flex justify-between text-[11px] text-slate-600">
                      <span>50 kW</span>
                      <span>250 kW</span>
                    </div>

                  </div>

                </div>

                <section className="mt-6 rounded-2xl border border-white/10 bg-white/[0.035]">

                  <div className="flex items-center justify-between border-b border-white/10 p-5">

                    <div>

                      <p className="text-xs font-semibold uppercase tracking-widest text-slate-600">
                        Fleet
                      </p>

                      <h2 className="mt-1 text-xl font-semibold">
                        Active Charging
                        Sessions
                      </h2>

                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        setActiveSection(
                          "Vehicles"
                        )
                      }
                      className="text-sm text-orange-400 hover:text-orange-300"
                    >
                      View all →
                    </button>

                  </div>

                  <div className="overflow-x-auto">

                    <table className="w-full min-w-[750px] text-left">

                      <thead>

                        <tr className="border-b border-white/5 text-xs uppercase tracking-wider text-slate-600">

                          <th className="px-5 py-4">
                            Vehicle
                          </th>

                          <th className="px-5 py-4">
                            Demand
                          </th>

                          <th className="px-5 py-4">
                            Battery
                          </th>

                          <th className="px-5 py-4">
                            Priority
                          </th>

                          <th className="px-5 py-4">
                            Allocated
                          </th>

                          <th className="px-5 py-4">
                            Status
                          </th>

                        </tr>

                      </thead>

                      <tbody>

                        {allocations.map(
                          (vehicle) => (
                            <VehicleRow
                              key={
                                vehicle.id
                              }
                              vehicle={
                                vehicle
                              }
                            />
                          )
                        )}

                      </tbody>

                    </table>

                  </div>

                </section>

              </>
            )}

            {/* VEHICLES */}

            {activeSection ===
              "Vehicles" && (
              <section>

                <SectionHeading
                  eyebrow="FLEET MANAGEMENT"
                  title="Vehicles"
                  description="Monitor vehicle energy requirements and optimized power allocation."
                />

                <div className="grid gap-5 md:grid-cols-2">

                  {allocations.map(
                    (vehicle) => (
                      <div
                        key={
                          vehicle.id
                        }
                        className="rounded-2xl border border-white/10 bg-white/[0.035] p-6"
                      >

                        <div className="flex items-start justify-between">

                          <div className="flex items-center gap-3">

                            <div className="rounded-xl bg-orange-500/10 p-3 text-orange-400">
                              <Car size={22} />
                            </div>

                            <div>

                              <h3 className="font-semibold">
                                {vehicle.name}
                              </h3>

                              <p className="text-xs text-slate-600">
                                {vehicle.id}
                              </p>

                            </div>

                          </div>

                          <StatusBadge
                            status={
                              vehicle.status
                            }
                          />

                        </div>

                        <div className="mt-6 grid grid-cols-3 gap-3">

                          <MiniStat
                            label="Battery"
                            value={`${vehicle.battery} kWh`}
                          />

                          <MiniStat
                            label="Demand"
                            value={`${vehicle.demand} kW`}
                          />

                          <MiniStat
                            label="Allocated"
                            value={`${vehicle.allocated} kW`}
                          />

                        </div>

                        <div className="mt-5">

                          <div className="flex justify-between text-xs">

                            <span className="text-slate-500">
                              Charging allocation
                            </span>

                            <span className="text-slate-400">
                              {Math.round(
                                (vehicle.allocated /
                                  Math.max(
                                    vehicle.demand,
                                    1
                                  )) *
                                  100
                              )}
                              %
                            </span>

                          </div>

                          <div className="mt-2 h-2 rounded-full bg-slate-800">

                            <div
                              className="h-full rounded-full bg-emerald-400"
                              style={{
                                width: `${Math.min(
                                  (vehicle.allocated /
                                    Math.max(
                                      vehicle.demand,
                                      1
                                    )) *
                                    100,
                                  100
                                )}%`,
                              }}
                            />

                          </div>

                        </div>

                      </div>
                    )
                  )}

                </div>

              </section>
            )}

            {/* CHARGING */}

            {activeSection ===
              "Charging" && (
              <section>

                <SectionHeading
                  eyebrow="ENERGY MANAGEMENT"
                  title="Charging"
                  description="Calculate the energy, time, and estimated cost required to charge your EV."
                />

                <ChargingCalculator />

              </section>
            )}

            {/* STATIONS */}

            {activeSection ===
              "Stations" && (
              <section>

                <SectionHeading
                  eyebrow="LIVE INFRASTRUCTURE"
                  title="Charging Stations"
                  description="Find real charging stations across India using live Open Charge Map data."
                />

                <div className="mb-6 rounded-2xl border border-white/10 bg-white/[0.035] p-5">

                  <div className="flex flex-col gap-3 md:flex-row">

                    <input
                      type="text"
                      value={
                        stationSearch
                      }
                      onChange={(e) =>
                        setStationSearch(
                          e.target.value
                        )
                      }
                      onKeyDown={(e) => {
                        if (
                          e.key ===
                          "Enter"
                        ) {
                          searchStations();
                        }
                      }}
                      placeholder="Search city e.g. Delhi, Hyderabad, Mumbai..."
                      className="w-full rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-white outline-none placeholder:text-slate-600 focus:border-orange-500/40"
                    />

                    <button
                      type="button"
                      onClick={
                        searchStations
                      }
                      className="rounded-xl bg-orange-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-orange-400"
                    >
                      Search
                    </button>

                    <button
                      type="button"
                      onClick={
                        showAllIndia
                      }
                      className="rounded-xl border border-white/10 px-6 py-3 text-sm text-slate-400 transition hover:bg-white/5 hover:text-white"
                    >
                      All India
                    </button>

                  </div>

                  <p className="mt-3 text-xs text-slate-600">
                    {appliedSearch
                      ? `Showing results for "${appliedSearch}"`
                      : "Showing India-wide station results"}
                  </p>

                </div>

                {loading ? (

                  <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-10 text-center text-slate-500">
                    Loading charging
                    stations...
                  </div>

                ) : stations.length ===
                  0 ? (

                  <div className="rounded-2xl border border-red-500/10 bg-red-500/5 p-10 text-center text-red-400">
                    No charging stations
                    found. Try another
                    city.
                  </div>

                ) : (

                  <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">

                    {stations.map(
                      (
                        station,
                        index
                      ) => {

                        const address =
                          station.AddressInfo;

                        const connection =
                          station
                            .Connections?.[0];

                        const connectorType =
                          connection
                            ?.ConnectionType
                            ?.Title ||
                          connection
                            ?.ConnectionType
                            ?.FormalName ||
                          "Unavailable";

                        return (
                          <div
                            key={`${station.ID}-${index}`}
                            className="rounded-2xl border border-white/10 bg-white/[0.035] p-5 transition hover:-translate-y-0.5 hover:border-emerald-500/20 hover:bg-white/[0.05]"
                          >

                            <div className="flex items-start justify-between gap-3">

                              <div className="flex items-start gap-3">

                                <div className="rounded-xl bg-emerald-500/10 p-3 text-emerald-400">
                                  <MapPin
                                    size={19}
                                  />
                                </div>

                                <div>

                                  <h3 className="font-semibold">
                                    {address?.Title ||
                                      "EV Charging Station"}
                                  </h3>

                                  <p className="mt-1 text-xs text-slate-500">
                                    {address?.Town ||
                                      "Unknown"}
                                    ,{" "}
                                    {address?.StateOrProvince ||
                                      "India"}
                                  </p>

                                </div>

                              </div>

                              <span className="rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-medium text-emerald-400">
                                DATA
                              </span>

                            </div>

                            <div className="mt-5 grid grid-cols-2 gap-3">

                              <MiniStat
                                label="Power"
                                value={`${connection?.PowerKW ?? "—"} kW`}
                              />

                              <MiniStat
                                label="Connectors"
                                value={`${connection?.Quantity ?? 1}`}
                              />

                              <MiniStat
                                label="Connector Type"
                                value={
                                  connectorType
                                }
                              />

                              <MiniStat
                                label="Station ID"
                                value={`${station.ID}`}
                              />

                            </div>

                            <div className="mt-4 rounded-xl border border-white/5 bg-black/10 p-3">

                              <p className="text-[11px] uppercase tracking-wide text-slate-600">
                                Location
                              </p>

                              <p className="mt-1 text-xs text-slate-400">

                                {address?.Latitude !==
                                undefined
                                  ? address.Latitude.toFixed(
                                      4
                                    )
                                  : "—"}

                                ,{" "}

                                {address?.Longitude !==
                                undefined
                                  ? address.Longitude.toFixed(
                                      4
                                    )
                                  : "—"}

                              </p>

                            </div>

                            {address?.Latitude !==
                              undefined &&
                              address?.Longitude !==
                                undefined && (
                                <a
                                  href={`https://www.google.com/maps?q=${address.Latitude},${address.Longitude}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="mt-4 flex items-center justify-center rounded-xl border border-white/10 px-4 py-2.5 text-xs font-medium text-slate-400 transition hover:bg-white/5 hover:text-white"
                                >
                                  📍 Open in Google Maps
                                </a>
                              )}

                          </div>
                        );
                      }
                    )}

                  </div>

                )}

              </section>
            )}

            {/* COSTS */}

            {activeSection ===
              "Costs" && (
              <section>

                <SectionHeading
                  eyebrow="ENERGY ECONOMICS"
                  title="Charging Costs"
                  description="Estimate your fleet's charging cost based on allocated power and electricity tariff."
                />

                <div className="grid gap-5 md:grid-cols-3">

                  <LargeMetric
                    label="Electricity Tariff"
                    value={`₹${tariff}`}
                    suffix="/kWh"
                    icon={
                      <Zap size={22} />
                    }
                  />

                  <LargeMetric
                    label="Energy Used"
                    value={energyUsed.toFixed(
                      1
                    )}
                    suffix="kWh"
                    icon={
                      <BatteryCharging
                        size={22}
                      />
                    }
                  />

                  <LargeMetric
                    label="Estimated Cost"
                    value={`₹${estimatedCost.toFixed(
                      2
                    )}`}
                    suffix=""
                    icon={
                      <CircleDollarSign
                        size={22}
                      />
                    }
                  />

                </div>

                <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.035] p-6">

                  <div className="flex items-center justify-between">

                    <div>

                      <h2 className="font-semibold">
                        Electricity Tariff
                      </h2>

                      <p className="mt-1 text-sm text-slate-500">
                        Adjust the rate used
                        for cost estimation.
                      </p>

                    </div>

                    <span className="text-2xl font-bold text-emerald-400">
                      ₹{tariff}/kWh
                    </span>

                  </div>

                  <input
                    type="range"
                    min="5"
                    max="25"
                    step="1"
                    value={tariff}
                    onChange={(e) =>
                      setTariff(
                        Number(
                          e.target.value
                        )
                      )
                    }
                    className="mt-7 w-full accent-emerald-400"
                  />

                  <div className="mt-2 flex justify-between text-xs text-slate-600">
                    <span>₹5</span>
                    <span>₹25</span>
                  </div>

                </div>

                <div className="mt-5 rounded-2xl border border-orange-500/10 bg-orange-500/[0.035] p-6">

                  <p className="text-sm font-semibold text-orange-400">
                    Cost calculation
                  </p>

                  <p className="mt-3 text-sm leading-7 text-slate-400">

                    {energyUsed.toFixed(
                      1
                    )}{" "}
                    kWh × ₹{tariff}/kWh ×
                    1 hour session ={" "}

                    <span className="font-semibold text-white">
                      ₹
                      {estimatedCost.toFixed(
                        2
                      )}
                    </span>

                  </p>

                </div>

              </section>
            )}

            {/* SETTINGS */}

            {activeSection ===
              "Settings" && (
              <section>

                <SectionHeading
                  eyebrow="SYSTEM CONFIGURATION"
                  title="Settings"
                  description="Configure the parameters used by the GridCharge optimization engine."
                />

                <div className="max-w-3xl space-y-5">

                  <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6">

                    <div className="flex items-center gap-3">

                      <div className="rounded-xl bg-orange-500/10 p-3 text-orange-400">
                        <Gauge size={21} />
                      </div>

                      <div>

                        <h2 className="font-semibold">
                          Site Power Limit
                        </h2>

                        <p className="text-sm text-slate-500">
                          Maximum power
                          available to your
                          EV fleet.
                        </p>

                      </div>

                    </div>

                    <div className="mt-7 flex items-center justify-between">

                      <span className="text-sm text-slate-500">
                        Current limit
                      </span>

                      <span className="text-2xl font-bold text-orange-400">
                        {siteLimit} kW
                      </span>

                    </div>

                    <input
                      type="range"
                      min="50"
                      max="250"
                      step="10"
                      value={siteLimit}
                      onChange={(e) =>
                        setSiteLimit(
                          Number(
                            e.target.value
                          )
                        )
                      }
                      className="mt-5 w-full accent-orange-500"
                    />

                    <div className="mt-2 flex justify-between text-xs text-slate-600">
                      <span>
                        50 kW
                      </span>
                      <span>
                        250 kW
                      </span>
                    </div>

                  </div>

                  <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6">

                    <div className="flex items-center gap-3">

                      <div className="rounded-xl bg-emerald-500/10 p-3 text-emerald-400">
                        <CircleDollarSign
                          size={21}
                        />
                      </div>

                      <div>

                        <h2 className="font-semibold">
                          Electricity Tariff
                        </h2>

                        <p className="text-sm text-slate-500">
                          Price used to
                          estimate fleet
                          charging cost.
                        </p>

                      </div>

                    </div>

                    <div className="mt-7 flex items-center justify-between">

                      <span className="text-sm text-slate-500">
                        Current tariff
                      </span>

                      <span className="text-2xl font-bold text-emerald-400">
                        ₹{tariff}/kWh
                      </span>

                    </div>

                    <input
                      type="range"
                      min="5"
                      max="25"
                      step="1"
                      value={tariff}
                      onChange={(e) =>
                        setTariff(
                          Number(
                            e.target.value
                          )
                        )
                      }
                      className="mt-5 w-full accent-emerald-400"
                    />

                    <div className="mt-2 flex justify-between text-xs text-slate-600">
                      <span>
                        ₹5
                      </span>
                      <span>
                        ₹25
                      </span>
                    </div>

                  </div>

                  <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6">

                    <div className="flex items-center gap-3">

                      <div className="rounded-xl bg-purple-500/10 p-3 text-purple-400">
                        <Settings
                          size={21}
                        />
                      </div>

                      <div>

                        <h2 className="font-semibold">
                          Optimization Engine
                        </h2>

                        <p className="text-sm text-slate-500">
                          Current fleet power
                          management status.
                        </p>

                      </div>

                    </div>

                    <div className="mt-6 flex items-center justify-between rounded-xl bg-emerald-500/5 p-4">

                      <div>

                        <p className="text-sm font-medium">
                          Priority-based
                          allocation
                        </p>

                        <p className="mt-1 text-xs text-slate-600">
                          Higher-priority
                          vehicles receive
                          available power
                          first.
                        </p>

                      </div>

                      <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-400">
                        ACTIVE
                      </span>

                    </div>

                  </div>

                </div>

              </section>
            )}

          </div>

        </section>

      </div>
    </main>
  );
}

/* =========================
   COMPONENTS
========================= */

function MetricCard({
  label,
  value,
  description,
  icon,
  iconClass,
}: {
  label: string;
  value: string;
  description: string;
  icon: ReactNode;
  iconClass: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-5 shadow-2xl shadow-black/10">

      <div className="flex items-center justify-between">

        <p className="text-sm text-slate-500">
          {label}
        </p>

        <div className={iconClass}>
          {icon}
        </div>

      </div>

      <p className="mt-4 text-3xl font-bold">
        {value}
      </p>

      <p className="mt-2 text-xs text-slate-600">
        {description}
      </p>

    </div>
  );
}

function VehicleRow({
  vehicle,
}: {
  vehicle: Allocation;
}) {
  return (
    <tr className="border-b border-white/5 last:border-0 hover:bg-white/[0.02]">

      <td className="px-5 py-4">

        <div className="flex items-center gap-3">

          <div className="rounded-lg bg-orange-500/10 p-2 text-orange-400">
            <Car size={17} />
          </div>

          <div>

            <p className="text-sm font-medium">
              {vehicle.name}
            </p>

            <p className="text-xs text-slate-600">
              {vehicle.id}
            </p>

          </div>

        </div>

      </td>

      <td className="px-5 py-4 text-sm">
        {vehicle.demand} kW
      </td>

      <td className="px-5 py-4 text-sm text-slate-400">
        {vehicle.battery} kWh
      </td>

      <td className="px-5 py-4">

        <span className="rounded-full bg-white/5 px-2.5 py-1 text-xs">
          {vehicle.priority}/10
        </span>

      </td>

      <td className="px-5 py-4 text-sm font-semibold">
        {vehicle.allocated} kW
      </td>

      <td className="px-5 py-4">
        <StatusBadge
          status={vehicle.status}
        />
      </td>

    </tr>
  );
}

function StatusBadge({
  status,
}: {
  status: Allocation["status"];
}) {
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-xs font-medium ${
        status === "Charging"
          ? "bg-emerald-500/10 text-emerald-400"
          : status === "Throttled"
          ? "bg-yellow-500/10 text-yellow-400"
          : "bg-slate-500/10 text-slate-500"
      }`}
    >
      {status}
    </span>
  );
}

function SectionHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <div className="mb-8">

      <p className="text-xs font-semibold uppercase tracking-widest text-orange-400">
        {eyebrow}
      </p>

      <h1 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">
        {title}
      </h1>

      <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500 md:text-base">
        {description}
      </p>

    </div>
  );
}

function MiniStat({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-white/5 bg-black/10 p-3">

      <p className="text-[11px] uppercase tracking-wide text-slate-600">
        {label}
      </p>

      <p className="mt-1 text-sm font-semibold">
        {value}
      </p>

    </div>
  );
}

function LargeMetric({
  label,
  value,
  suffix,
  icon,
}: {
  label: string;
  value: string;
  suffix: string;
  icon: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6">

      <div className="flex items-center justify-between">

        <p className="text-sm text-slate-500">
          {label}
        </p>

        <div className="rounded-xl bg-orange-500/10 p-3 text-orange-400">
          {icon}
        </div>

      </div>

      <p className="mt-6 text-3xl font-bold">

        {value}

        {suffix && (
          <span className="ml-1 text-sm font-normal text-slate-500">
            {suffix}
          </span>
        )}

      </p>

    </div>
  );
}