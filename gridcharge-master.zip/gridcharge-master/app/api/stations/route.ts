import { NextResponse } from "next/server";

const CITY_COORDINATES: Record<
  string,
  { latitude: number; longitude: number }
> = {
  delhi: {
    latitude: 28.6139,
    longitude: 77.209,
  },

  "new delhi": {
    latitude: 28.6139,
    longitude: 77.209,
  },

  mumbai: {
    latitude: 19.076,
    longitude: 72.8777,
  },

  hyderabad: {
    latitude: 17.385,
    longitude: 78.4867,
  },

  bengaluru: {
    latitude: 12.9716,
    longitude: 77.5946,
  },

  bangalore: {
    latitude: 12.9716,
    longitude: 77.5946,
  },

  chennai: {
    latitude: 13.0827,
    longitude: 80.2707,
  },

  kolkata: {
    latitude: 22.5726,
    longitude: 88.3639,
  },

  pune: {
    latitude: 18.5204,
    longitude: 73.8567,
  },

  ahmedabad: {
    latitude: 23.0225,
    longitude: 72.5714,
  },

  jaipur: {
    latitude: 26.9124,
    longitude: 75.7873,
  },

  lucknow: {
    latitude: 26.8467,
    longitude: 80.9462,
  },

  chandigarh: {
    latitude: 30.7333,
    longitude: 76.7794,
  },

  kochi: {
    latitude: 9.9312,
    longitude: 76.2673,
  },

  indore: {
    latitude: 22.7196,
    longitude: 75.8577,
  },

  bhopal: {
    latitude: 23.2599,
    longitude: 77.4126,
  },

  nagpur: {
    latitude: 21.1458,
    longitude: 79.0882,
  },

  surat: {
    latitude: 21.1702,
    longitude: 72.8311,
  },

  visakhapatnam: {
    latitude: 17.6868,
    longitude: 83.2185,
  },

  vijayawada: {
    latitude: 16.5062,
    longitude: 80.648,
  },
};

export async function GET(request: Request) {
  try {
    const apiKey = process.env.OPEN_CHARGE_MAP_API_KEY;

    if (!apiKey) {
      return NextResponse.json(
        {
          error: "Open Charge Map API key is missing",
        },
        {
          status: 500,
        }
      );
    }

    const { searchParams } = new URL(request.url);

    const city = searchParams
      .get("city")
      ?.trim()
      .toLowerCase();

    let url =
      "https://api.openchargemap.io/v3/poi/" +
      "?output=json" +
      "&countrycode=IN" +
      "&maxresults=50" +
      "&compact=true" +
      "&verbose=false" +
      `&key=${apiKey}`;

    /*
     * If a city was searched, request stations
     * around that city's coordinates.
     */

    if (city) {
      const location = CITY_COORDINATES[city];

      if (!location) {
        return NextResponse.json(
          {
            error:
              "City not supported yet. Try Delhi, Mumbai, Hyderabad, Bengaluru, Chennai, Pune, etc.",
          },
          {
            status: 400,
          }
        );
      }

      url +=
        `&latitude=${location.latitude}` +
        `&longitude=${location.longitude}` +
        "&distance=50" +
        "&distanceunit=KM";
    }

    const controller = new AbortController();

    const timeout = setTimeout(() => {
      controller.abort();
    }, 8000);

    try {
      const response = await fetch(url, {
        signal: controller.signal,
        cache: "no-store",
        headers: {
          "User-Agent": "GridCharge EV Charging Platform",
        },
      });

      if (!response.ok) {
        return NextResponse.json(
          {
            error: "Open Charge Map request failed",
          },
          {
            status: response.status,
          }
        );
      }

      const stations = await response.json();

      return NextResponse.json(stations);
    } finally {
      clearTimeout(timeout);
    }
  } catch (error) {
    console.error("Station API error:", error);

    return NextResponse.json(
      {
        error: "Failed to fetch charging stations",
      },
      {
        status: 500,
      }
    );
  }
}