"use client";

import { useMemo, useState } from "react";
import { BatteryCharging, Clock3, CircleDollarSign, Zap } from "lucide-react";

type VehicleOption = {
  name: string;
  battery: number;
  maxPower: number;
};

const vehicles: VehicleOption[] = [
  {
    name: "Delivery Van",
    battery: 35,
    maxPower: 70,
  },
  {
    name: "Fleet Car",
    battery: 22,
    maxPower: 50,
  },
  {
    name: "Taxi",
    battery: 28,
    maxPower: 60,
  },
  {
    name: "Service Van",
    battery: 18,
    maxPower: 40,
  },
  {
    name: "Electric Bike",
    battery: 4,
    maxPower: 1,
  },
];

export function ChargingCalculator() {
  const [vehicleName, setVehicleName] =
    useState("Fleet Car");

  const [currentSoc, setCurrentSoc] =
    useState(20);

  const [targetSoc, setTargetSoc] =
    useState(80);

  const [chargingPower, setChargingPower] =
    useState(7);

  const [tariff, setTariff] =
    useState(8);

  const selectedVehicle =
    vehicles.find(
      (vehicle) =>
        vehicle.name === vehicleName
    ) ?? vehicles[1];

  const calculation = useMemo(() => {
    const socDifference = Math.max(
      targetSoc - currentSoc,
      0
    );

    const batteryEnergy =
      selectedVehicle.battery *
      (socDifference / 100);

    /*
     * Approximate charging efficiency.
     * 90% means the charger/grid must supply
     * slightly more energy than reaches the battery.
     */

    const chargingEfficiency = 0.9;

    const gridEnergy =
      batteryEnergy / chargingEfficiency;

    const effectivePower = Math.min(
      Math.max(chargingPower, 0.1),
      selectedVehicle.maxPower
    );

    const chargingTimeHours =
      gridEnergy / effectivePower;

    const chargingTimeMinutes =
      chargingTimeHours * 60;

    const estimatedCost =
      gridEnergy * tariff;

    return {
      batteryEnergy,
      gridEnergy,
      chargingTimeHours,
      chargingTimeMinutes,
      estimatedCost,
    };
  }, [
    currentSoc,
    targetSoc,
    chargingPower,
    tariff,
    selectedVehicle,
  ]);

  const formatTime = (
    minutes: number
  ) => {
    if (minutes <= 0) {
      return "0 min";
    }

    const hours = Math.floor(
      minutes / 60
    );

    const remainingMinutes =
      Math.round(minutes % 60);

    if (hours === 0) {
      return `${remainingMinutes} min`;
    }

    if (remainingMinutes === 0) {
      return `${hours} hr`;
    }

    return `${hours} hr ${remainingMinutes} min`;
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-6">

      {/* HEADER */}

      <div className="flex items-center gap-3">

        <div className="rounded-xl bg-orange-500/10 p-3 text-orange-400">
          <BatteryCharging size={22} />
        </div>

        <div>
          <h2 className="text-lg font-semibold">
            Charging Calculator
          </h2>

          <p className="text-sm text-slate-500">
            Estimate energy, charging time and cost.
          </p>
        </div>

      </div>

      {/* INPUTS */}

      <div className="mt-7 grid gap-5 md:grid-cols-2">

        {/* VEHICLE */}

        <div>
          <label className="text-xs font-medium uppercase tracking-wide text-slate-500">
            Vehicle
          </label>

          <select
            value={vehicleName}
            onChange={(e) =>
              setVehicleName(
                e.target.value
              )
            }
            className="mt-2 w-full rounded-xl border border-white/10 bg-[#080c1c] px-4 py-3 text-sm text-white outline-none focus:border-orange-500/40"
          >
            {vehicles.map(
              (vehicle) => (
                <option
                  key={vehicle.name}
                  value={vehicle.name}
                >
                  {vehicle.name} —{" "}
                  {vehicle.battery} kWh
                </option>
              )
            )}
          </select>
        </div>

        {/* CHARGING POWER */}

        <div>
          <label className="text-xs font-medium uppercase tracking-wide text-slate-500">
            Charging Power
          </label>

          <div className="mt-2 flex items-center gap-3">

            <input
              type="number"
              min="0.1"
              max={
                selectedVehicle.maxPower
              }
              step="0.1"
              value={chargingPower}
              onChange={(e) =>
                setChargingPower(
                  Number(e.target.value)
                )
              }
              className="w-full rounded-xl border border-white/10 bg-[#080c1c] px-4 py-3 text-sm text-white outline-none focus:border-orange-500/40"
            />

            <span className="text-sm text-slate-500">
              kW
            </span>

          </div>

          <p className="mt-2 text-xs text-slate-600">
            Vehicle limit:{" "}
            {selectedVehicle.maxPower} kW
          </p>
        </div>

        {/* CURRENT SOC */}

        <div>

          <div className="flex justify-between">
            <label className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Current Battery
            </label>

            <span className="text-sm font-semibold text-orange-400">
              {currentSoc}%
            </span>
          </div>

          <input
            type="range"
            min="0"
            max="100"
            value={currentSoc}
            onChange={(e) =>
              setCurrentSoc(
                Number(e.target.value)
              )
            }
            className="mt-4 w-full accent-orange-500"
          />

        </div>

        {/* TARGET SOC */}

        <div>

          <div className="flex justify-between">

            <label className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Target Battery
            </label>

            <span className="text-sm font-semibold text-emerald-400">
              {targetSoc}%
            </span>

          </div>

          <input
            type="range"
            min="0"
            max="100"
            value={targetSoc}
            onChange={(e) =>
              setTargetSoc(
                Number(e.target.value)
              )
            }
            className="mt-4 w-full accent-emerald-400"
          />

        </div>

        {/* TARIFF */}

        <div className="md:col-span-2">

          <div className="flex justify-between">

            <label className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Electricity Tariff
            </label>

            <span className="text-sm font-semibold text-purple-400">
              ₹{tariff}/kWh
            </span>

          </div>

          <input
            type="range"
            min="1"
            max="30"
            step="0.5"
            value={tariff}
            onChange={(e) =>
              setTariff(
                Number(e.target.value)
              )
            }
            className="mt-4 w-full accent-purple-400"
          />

        </div>

      </div>

      {/* RESULTS */}

      <div className="mt-8 grid gap-4 sm:grid-cols-3">

        {/* ENERGY */}

        <div className="rounded-2xl border border-white/10 bg-black/10 p-5">

          <div className="flex items-center gap-2 text-emerald-400">

            <Zap size={18} />

            <span className="text-xs uppercase tracking-wide">
              Energy Needed
            </span>

          </div>

          <p className="mt-3 text-2xl font-bold">
            {calculation.gridEnergy.toFixed(
              2
            )}{" "}
            <span className="text-sm font-normal text-slate-500">
              kWh
            </span>
          </p>

          <p className="mt-1 text-xs text-slate-600">
            Including 10% charging losses
          </p>

        </div>

        {/* TIME */}

        <div className="rounded-2xl border border-white/10 bg-black/10 p-5">

          <div className="flex items-center gap-2 text-orange-400">

            <Clock3 size={18} />

            <span className="text-xs uppercase tracking-wide">
              Charging Time
            </span>

          </div>

          <p className="mt-3 text-2xl font-bold">
            {formatTime(
              calculation.chargingTimeMinutes
            )}
          </p>

          <p className="mt-1 text-xs text-slate-600">
            At {Math.min(
              chargingPower,
              selectedVehicle.maxPower
            )} kW
          </p>

        </div>

        {/* COST */}

        <div className="rounded-2xl border border-white/10 bg-black/10 p-5">

          <div className="flex items-center gap-2 text-purple-400">

            <CircleDollarSign
              size={18}
            />

            <span className="text-xs uppercase tracking-wide">
              Estimated Cost
            </span>

          </div>

          <p className="mt-3 text-2xl font-bold">
            ₹
            {calculation.estimatedCost.toFixed(
              2
            )}
          </p>

          <p className="mt-1 text-xs text-slate-600">
            Based on ₹{tariff}/kWh
          </p>

        </div>

      </div>

      {/* TECHNICAL NOTE */}

      <div className="mt-5 rounded-xl border border-white/5 bg-white/[0.02] p-4">

        <p className="text-xs leading-5 text-slate-500">

          Calculation uses battery capacity,
          state of charge (SOC), charging power,
          and an assumed 90% charging efficiency.
          Actual charging time can vary because of
          charger limits, battery temperature,
          battery management systems, and charging
          taper at high SOC.

        </p>

      </div>

    </div>
  );
}