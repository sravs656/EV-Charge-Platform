# GridCharge ⚡

### Grid-Aware EV Fleet Charging Orchestration Platform

GridCharge is a prototype designed to help manage multiple EV chargers operating under a shared electrical power limit.

## 🚨 Problem

When multiple EVs charge simultaneously, the total power demand can exceed the available electrical capacity of a site.

This can result in:

* ⚡ Electrical overload
* 💰 Higher demand charges
* 🔌 Inefficient power allocation

## 💡 Solution

GridCharge provides a centralized platform for monitoring EV charging activity and managing charging across shared infrastructure.

## ✨ Features

* 🔐 User authentication
* 🚗 Vehicle management
* 🔌 Charger management
* ⚡ Charging session monitoring
* 📊 Charging dashboard
* 🏢 Multi-tenant charging management

## 🛠️ Technologies

* Next.js
* TypeScript
* Supabase
* Tailwind CSS
* Vercel

## 🚀 Live Demo

**https://gridcharge.vercel.app/**

## 🏆 Hackathon

Built as a prototype during **Hack Devengers 1.0**.

## 👩‍💻 My Contribution

I independently developed this prototype during the hackathon, working on the application structure, user interface, functionality, authentication, and integration with the backend services.

## 📌 Project Status

This is a hackathon prototype that can be further developed with features such as real-time power allocation, charger communication, and advanced load optimization.

